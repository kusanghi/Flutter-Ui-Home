#!/bin/bash
sudo apt-get update -y && \
sudo apt-get install net-tools htop -y && \
sudo apt install openssh-server -y && \
sudo systemctl enable ssh && \
sudo mkdir -p /home/vccnuc/.ssh && \
/bin/sh -c "echo 'ssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAACAQC8zBBG7a7fVxFyyOAigru08gtDYU2kwQ1ofuvhWKgHiq4/IGEdjXqSTVTh36tpJ3saG1DF5lHQMXF3aqS6Dzw7HVDVZi3N4XLUZ6XdaAXZ7a4RKQftCft2OOsgONBh63qYO7U7CgOzn7W+vyALszC1IcS9a+6oJFwOIqqiloUwnqQopgV1dy58Emmt4DpUrPc9fo7xGQJjnbT2sqHbwI9DkootJmhupOS98VBSVOyw4oPkxuqV3lbvJgMoKna/KIfCKRBEPO42nbMlYFMzB0yKuUFyY4inYRu4126LR12ODzVnD2QPfl1vSO3oXBLAi7xlZ747Z1obmEEdR+XuZ+XLC00I/XW0bJ1WX4DvJv9l/Mk0TPOFQFhJG7LGf69W7yLWKS7+NAcy5rn1CrXe1I4BLLC9Dr0b2Wwi6io1iOl92rkK3DUSttmgvu16eWOCUbu/Zu3OuULZMm3NnMtilVm8Rb7qzptTOAaSxZOQ2azSxqslvE0CHMC50kmOvA3WvqFV/eIwxE0xpzQOqkdyMTQnTRQPgfCfg9ifYo/+peH3h+D6G8x27+OKUgTdbnrprYo8zgxUwvEbgaSnb/IoZ/+Ah8iGHsFsc2LpERpY+76ChKSl9l5XMSbxkPKow0ctQ+IuRhVYqvq6+k0LXIlg3H2/LzhYKGYwks+v0Hy5Ck2YSQ== vcloudcamdev@vng.com.vn' >> /home/vccnuc/.ssh/authorized_keys" && \

sudo chown -R vccnuc:vccnuc /home/vccnuc/ && \
sudo chmod -R go-rwx /home/vccnuc/.ssh/authorized_keys && \
sudo sed -i 's/PermitRootLogin yes/PermitRootLogin no/g' /etc/ssh/sshd_config && \
sudo dpkg --install vbox_nuc_dpkg.deb && \
sudo service hub stop && \
sudo cp config.json /home/vccnuc/hub/config.json && \
sudo cp hub-3.1.2-linux-amd64 /home/vccnuc/hub/hub && \
sudo chmod +x /home/vccnuc/hub/hub && \
sudo service hub restart && \
sudo systemctl status hub --no-pager && \
echo "================= DONE!"

